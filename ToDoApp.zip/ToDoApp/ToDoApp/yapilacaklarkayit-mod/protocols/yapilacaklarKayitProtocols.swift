//
//  yapilacaklarKayitProtocols.swift
//  ToDoApp
//
//  Created by MTK on 9.09.2022.
//

import Foundation
//Ana protocoller
protocol ViewToPresenteryapilacaklarKayitProtocol {
    var yapilacaklarKayitInteractor:PresenterToInteractoryapilacaklarKayitProtocol? {get set}
    
    func ekle(yapilacak_is:String)
}

protocol PresenterToInteractoryapilacaklarKayitProtocol {
    func yapilacakEkle(yapilacak_is:String)
}

//Router
protocol PresenterToRouteryapilacaklarKayitProtocol {
    static func createModule(ref:yapilacaklarKayitVC)
}
