//
//  yapilacaklarKayitRouter.swift
//  ToDoApp
//
//  Created by MTK on 9.09.2022.
//

import Foundation

class yapilacaklarKayitRouter : PresenterToRouteryapilacaklarKayitProtocol {
    static func createModule(ref: yapilacaklarKayitVC) {
        ref.yapilacaklarKayitPresenterNesnesi = yapilacaklarKayitPresenter()
        
        ref.yapilacaklarKayitPresenterNesnesi?.yapilacaklarKayitInteractor = yapilacaklarKayitInteractor()
    }
}

