//
//  yapilacaklarKayitVC.swift
//  ToDoApp
//
//  Created by MTK on 9.09.2022.
//

import UIKit

class yapilacaklarKayitVC: UIViewController {

    
    @IBOutlet weak var tfYapilacakIs: UITextField!
    
    
    
    
    
    var yapilacaklarKayitPresenterNesnesi:ViewToPresenteryapilacaklarKayitProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        yapilacaklarKayitRouter.createModule(ref: self)
    }
    
    @IBAction func buttonKaydet(_ sender: Any) {
        if let ka = tfYapilacakIs.text {
            yapilacaklarKayitPresenterNesnesi?.ekle(yapilacak_is: ka)
        }
    }
}
