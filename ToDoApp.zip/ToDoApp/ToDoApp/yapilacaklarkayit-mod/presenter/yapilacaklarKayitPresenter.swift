//
//  yapilacaklarKayitPresenter.swift
//  ToDoApp
//
//  Created by MTK on 9.09.2022.
//

import Foundation

class yapilacaklarKayitPresenter : ViewToPresenteryapilacaklarKayitProtocol {
    var yapilacaklarKayitInteractor: PresenterToInteractoryapilacaklarKayitProtocol?
    
    func ekle(yapilacak_is: String) {
        yapilacaklarKayitInteractor?.yapilacakEkle(yapilacak_is: yapilacak_is)
    }
}
