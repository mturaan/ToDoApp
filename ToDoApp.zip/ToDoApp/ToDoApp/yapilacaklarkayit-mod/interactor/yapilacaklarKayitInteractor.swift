//
//  yapilacaklarKayitInteractor.swift
//  ToDoApp
//
//  Created by MTK on 9.09.2022.
//

import Foundation

class yapilacaklarKayitInteractor : PresenterToInteractoryapilacaklarKayitProtocol{
    let db:FMDatabase?
    
    init(){
        let hedefYol = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        let veritabaniURL = URL(fileURLWithPath: hedefYol).appendingPathComponent("tododb.sqlite")
        db = FMDatabase(path: veritabaniURL.path)
    }
    
    
    func yapilacakEkle(yapilacak_is: String) {
        db?.open()
        
        do{
            try db!.executeUpdate("INSERT INTO yapilacaklar (yapilacak_is) VALUES (?)", values: [yapilacak_is])
        }catch{
            print(error.localizedDescription)
        }
        
        db?.close()
    }
}
