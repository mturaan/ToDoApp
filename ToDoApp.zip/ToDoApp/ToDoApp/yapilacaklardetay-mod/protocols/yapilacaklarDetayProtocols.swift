//
//  yapilacaklarDetayProtocols.swift
//  ToDoApp
//
//  Created by MTK on 9.09.2022.
//

import Foundation

//Ana protocoller
protocol ViewToPresenteryapilacaklarDetayProtocol {
    var yapilacaklarDetayInteractor:PresenterToInteractoryapilacaklarDetayProtocol? {get set}
    
    func guncelle(yapilacak_id:Int,yapilacak_is:String)
}

protocol PresenterToInteractoryapilacaklarDetayProtocol {
    func yapilacakGuncelle(yapilacak_id:Int,yapilacak_is:String)
}
//Router
protocol PresenterToRouteryapilacaklarDetayProtocol {
    static func createModule(ref:yapilacaklarDetayVC)
}
