//
//  yapilacaklarDetayPresenter.swift
//  ToDoApp
//
//  Created by MTK on 9.09.2022.
//

import Foundation

class yapilacaklarDetayPresenter : ViewToPresenteryapilacaklarDetayProtocol {
    var yapilacaklarDetayInteractor: PresenterToInteractoryapilacaklarDetayProtocol?
    
    func guncelle(yapilacak_id: Int, yapilacak_is: String) {
        yapilacaklarDetayInteractor?.yapilacakGuncelle(yapilacak_id: yapilacak_id, yapilacak_is: yapilacak_is)
    }
}
