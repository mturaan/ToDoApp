//
//  yapilacaklarDetayRouter.swift
//  ToDoApp
//
//  Created by MTK on 9.09.2022.
//

import Foundation

class yapilacaklarDetayRouter : PresenterToRouteryapilacaklarDetayProtocol {
    static func createModule(ref: yapilacaklarDetayVC) {
        ref.yapilacaklarDetayPresenterNesnesi = yapilacaklarDetayPresenter()
        
        ref.yapilacaklarDetayPresenterNesnesi?.yapilacaklarDetayInteractor = yapilacaklarDetayInteractor()
    }
}
