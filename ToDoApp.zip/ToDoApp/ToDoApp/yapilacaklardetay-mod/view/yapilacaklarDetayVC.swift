//
//  yapilacaklarDetayVC.swift
//  ToDoApp
//
//  Created by MTK on 9.09.2022.
//

import UIKit

class yapilacaklarDetayVC: UIViewController {

    @IBOutlet weak var tfYapilacakIs: UITextField!
    
    
    var yapilacak:Yapilacaklar?
    
    var yapilacaklarDetayPresenterNesnesi:ViewToPresenteryapilacaklarDetayProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        yapilacaklarDetayRouter.createModule(ref: self)
        
        if let k = yapilacak {
            tfYapilacakIs.text = k.yapilacak_is
            
        }
    }

    @IBAction func buttonGuncelle(_ sender: Any) {
        if let ka = tfYapilacakIs.text , let k = yapilacak {
            yapilacaklarDetayPresenterNesnesi?.guncelle(yapilacak_id: k.yapilacak_id!, yapilacak_is: ka)
        }
    }
}
